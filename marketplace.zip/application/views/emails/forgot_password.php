<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	Follow this link to reset your password.
	Link : <a href="<?php echo base_url();?>reset/<?php echo $codeVerication;?>"><?php echo base_url();?>reset/<?php echo $codeVerication;?></a>
</body>
</html>